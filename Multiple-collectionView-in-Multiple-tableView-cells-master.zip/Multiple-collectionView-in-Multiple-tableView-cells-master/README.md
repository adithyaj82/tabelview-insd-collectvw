# Multiple-collectionView-in-Multiple-tableView-cells
<a href = "https://user-images.githubusercontent.com/11716047/31836890-798833aa-b5f4-11e7-8bdc-96bddbf1ed82.gif"><img src = "https://user-images.githubusercontent.com/11716047/31836890-798833aa-b5f4-11e7-8bdc-96bddbf1ed82.gif"></a>
